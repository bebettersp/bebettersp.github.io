﻿
// GermDlg.cpp: 구현 파일
//

#include "pch.h"
#include "framework.h"
#include "Germ.h"
#include "GermDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif



// 응용 프로그램 정보에 사용되는 CAboutDlg 대화 상자입니다.

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

// 구현입니다.
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CGermDlg 대화 상자



CGermDlg::CGermDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_GERM_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	t_start = std::chrono::high_resolution_clock::now();
}

void CGermDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_CELL_NUM, m_strNumCell);
	DDX_Control(pDX, IDC_EDIT_GERMA_NUM, m_strNumGermA);
	DDX_Control(pDX, IDC_EDIT_GERMB_NUM, m_strNumGermB);
	DDX_Control(pDX, IDC_EDIT_GERMC_NUM, m_strNumGermC);
	DDX_Control(pDX, IDC_EDIT_GERMA_TIME, m_strTimeGermA);
	DDX_Control(pDX, IDC_EDIT_GERMB_TIME, m_strTimeGermB);
	DDX_Control(pDX, IDC_EDIT_GERMC_TIME, m_strTimeGermC);

	//DDX_Text(pDX, IDC_EDIT_CELL_NUM, m_strNumCell);
}

BEGIN_MESSAGE_MAP(CGermDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDOK2, &CGermDlg::OnBnClickedOk2)
END_MESSAGE_MAP()


// CGermDlg 메시지 처리기

BOOL CGermDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 시스템 메뉴에 "정보..." 메뉴 항목을 추가합니다.

	// IDM_ABOUTBOX는 시스템 명령 범위에 있어야 합니다.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 이 대화 상자의 아이콘을 설정합니다.  응용 프로그램의 주 창이 대화 상자가 아닐 경우에는
	//  프레임워크가 이 작업을 자동으로 수행합니다.
	SetIcon(m_hIcon, TRUE);			// 큰 아이콘을 설정합니다.
	SetIcon(m_hIcon, FALSE);		// 작은 아이콘을 설정합니다.

	// TODO: 여기에 추가 초기화 작업을 추가합니다.
	m_imgNormalCell.Load(_T("normal_cell.jpg"));
	m_imgInFectCell.Load(_T("infect_cell.jpg"));
	m_imgGermA.Load(_T("germA.jpg"));
	m_imgGermB.Load(_T("germB.jpg"));
	m_imgGermC.Load(_T("germC.jpg"));

	int n = 10, ng1 = 4, ng2 = 5, ng3 = 6;
	int d1 = 5, d2 = 150, d3 = 180;

	srand(time(nullptr));

	// vector<Cell> cells(n);
	// vector<Germ> germsA(ng1);
	// vector<Germ> germsB(ng2);
	// vector<Germ> germsC(ng3);
	cells.resize(n);
	germsA.resize(ng1);
	germsB.resize(ng2);
	germsC.resize(ng3);
	germATime = d1;
	germBTime = d2;
	germCTime = d3;

	/*germsA[0].time = d1;
	germsB[0].time = d2;
	germsC[0].time = d3;*/

	//std::thread myThread(simulate, cells, germsA, germsB, germsC);
	
	return TRUE;  // 포커스를 컨트롤에 설정하지 않으면 TRUE를 반환합니다.
}

void CGermDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 대화 상자에 최소화 단추를 추가할 경우 아이콘을 그리려면
//  아래 코드가 필요합니다.  문서/뷰 모델을 사용하는 MFC 애플리케이션의 경우에는
//  프레임워크에서 이 작업을 자동으로 수행합니다.

void CGermDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 그리기를 위한 디바이스 컨텍스트입니다.

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 클라이언트 사각형에서 아이콘을 가운데에 맞춥니다.
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		dc.DrawIcon(x, y, m_hIcon);

	}
	else
	{
		HWND hwnd = ::GetDlgItem(this->GetSafeHwnd(), IDC_STATIC);	// 그림 그릴 윈도우 핸들을 구해서
		CRect rect;
		::GetWindowRect(hwnd, rect);	// 그림 그릴 윈도우 크기 구하기

		HDC hdc = ::GetDC(hwnd);	// 그림 그릴 윈도우의 HDC 구하기
		HBITMAP hbmp = ::CreateCompatibleBitmap(hdc, rect.Width(), rect.Height());	// 그림 그릴 윈도우의 HBITMAP 구하기
		HBITMAP hbmpOld = (HBITMAP)::SelectObject(hdc, hbmp);	// 그림 그릴 윈도우의 HBITMAP 선택하기

		// todo .. : 사각형 그리기

		// todo .. : 원 그리기
		::Ellipse(hdc, 50, 5, 400, 400);

		// todo .. : 다각형 그리기
		int offset = 90;
		// todo .. : 선 그리기
		for (int i = 0; i < cells.size(); i++) {
			if (cells[i].infected) {
				m_imgInFectCell.Draw(hdc, cells[i].c * 20 + offset, cells[i].r * 20 + offset);
			}
			else {
				m_imgNormalCell.Draw(hdc, cells[i].c * 20 + offset, cells[i].r * 20 + offset);
			}
		}
		for (int i = 0; i < germsA.size(); i++) {
			m_imgGermA.Draw(hdc, germsA[i].c * 20 + offset, germsA[i].r * 20 + offset);
		}
		for (int i = 0; i < germsB.size(); i++) {
			m_imgGermB.Draw(hdc, germsB[i].c * 20 + offset, germsB[i].r * 20 + offset);
		}
		for (int i = 0; i < germsC.size(); i++) {
			m_imgGermC.Draw(hdc, germsC[i].c * 20 + offset, germsC[i].r * 20 + offset);
		}
	
		::SelectObject(hdc, hbmpOld);	// 기존 HBITMAP으로 돌리기
		::DeleteObject(hbmp);			// 사용한 HBITMAP 지우기
		::ReleaseDC(hwnd, hdc);		// HDC 해제
		::DeleteDC(hdc);				// HDC 지우기
		
		
		CDialogEx::OnPaint();
	}
}

// 사용자가 최소화된 창을 끄는 동안에 커서가 표시되도록 시스템에서
//  이 함수를 호출합니다.
HCURSOR CGermDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CGermDlg::printResult()
{
	string str;
	str.append("Program End\n");
	str.append("Program Terminal Reason: ");
	str.append(endReason.c_str());
	str.append("\n Normal Cell: " + std::to_string(nNormalCell));
	str.append("\n InFected Cell: " + std::to_string(nInFectCell));
	str.append("\n Number of Germ A: " + std::to_string(germsA.size()));
	str.append("\n Number of Germ B: " + std::to_string(germsB.size()));
	str.append("\n Number of Germ C: " + std::to_string(germsC.size()));
	CString sstr = (CString)str.c_str();
	
	cout << "========================================================\n";
	cout << "Program End\n";
	cout << "Program Terminal Reason: " << endReason.c_str() << endl;
	cout << "Normal Cell: " << nNormalCell << endl;
	cout << "InFected Cell: " << nInFectCell << endl;
	cout << "Number of Germ A: " << germsA.size() << endl;
	cout << "Number of Germ B: " << germsB.size() << endl;
	cout << "Number of Germ C: " << germsC.size() << endl;
	
	AfxMessageBox(sstr);
	isEndProcess = true;
}

bool CGermDlg::isEndCondition()
{
	auto t_end = std::chrono::high_resolution_clock::now();
	elapsed_time_ms = std::chrono::duration<double, std::milli>(t_end - t_start).count();
	if (elapsed_time_ms > 20000) {
		endReason = "Simulation Time is Over";
		cout << " time is over : " << elapsed_time_ms << endl;
		printResult();
		return true;
	}
	// is terminal condition?
	nInFectCell = cells.size() - nNormalCell;
	cout << "Number of remiained Cells " << nNormalCell << endl;
	cout << "Number of InFect Cells " << nInFectCell << endl;
	if (nNormalCell == 0) {
		endReason = "All Cells is Infected";
		printResult();
		return true;
	}


	if (elapsed_time_ms > germATime * 1000) {
		// if (true){
			// remove germ a
		cout << "germA is clear elaspsed time : " << elapsed_time_ms / 1000.0 << endl;
		germsA.clear();
	}

	if (elapsed_time_ms > germBTime * 1000) {
		cout << "germB is clear elaspsed time : " << elapsed_time_ms / 1000.0 << endl;
		germsB.clear();
	}

	if (elapsed_time_ms > germCTime * 1000) {
		cout << "germC is clear elaspsed time : " << elapsed_time_ms / 1000.0 << endl;
		germsC.clear();
	}

	if (germsA.size() == 0 && germsB.size() == 0 && germsC.size() == 0) {
		endReason = "All Germs is Clear";
		printResult();
		return true;
	}

	return false;
}

void CGermDlg::checkInfection()
{
	for (int i = 0; i < cells.size(); i++) {
		cout << cells[i].infected << " ";
		if (cells[i].infected) {
			continue;
		}

		if (cells[i].isInfectedBy(germsA) >= 0) {
			nNormalCell--;
			cout << "by germ A, remained : " << nNormalCell << endl;
		}
		else if (cells[i].isInfectedBy(germsB) >= 0) {
			nNormalCell--;
			cout << "by germ B, remained : " << nNormalCell << endl;
		}
		else if (cells[i].isInfectedBy(germsC) >= 0) {
			nNormalCell--;
			cout << "by germ C, remained : " << nNormalCell << endl;
		}
	}
}

void CGermDlg::moveAll()
{
	// move
	cout << "\nCELL\n";
	for (int i = 0; i < cells.size(); i++) {
		cells[i].move();
		cout << i << " : " << cells[i].r << " " << cells[i].c << endl;
	}

	cout << "GERM_A\n";
	for (int i = 0; i < germsA.size(); i++) {
		germsA[i].move();
		cout << i << " : " << germsA[i].r << " " << germsA[i].c << endl;
	}

	cout << "Germ B\n";
	for (int i = 0; i < germsB.size(); i++) {
		germsB[i].move();
		cout << i << " : " << germsB[i].r << " " << germsB[i].c << endl;
	}

	cout << "Germ C\n";
	for (int i = 0; i < germsC.size(); i++) {
		germsC[i].move();
		cout << i << " : " << germsC[i].r << " " << germsC[i].c << endl;
	}
}

//UINT __cdecl threadProc(void* cells, void* germsa, void* germsb, void* germsc)
UINT __cdecl threadProc(void *pdlg)
{
	/*vector<Cell> *_cells = (vector<Cell> *)cells;
	vector<Germ>* _germsa = (vector<Germ>*)germsa;
	vector<Germ>* _germsb = (vector<Germ>*)germsb;
	vector<Germ>* _germsc = (vector<Germ>*)germsc*/;
	CGermDlg* pDlg = (CGermDlg * )pdlg;
	pDlg->simulate();
	//while (true) {
	//	//cout << _cells->size() << endl;
	//}
	return 0;
}

int CGermDlg::getNumFromDlg(CEdit &_str)
{
	CString str;
	_str.GetWindowTextW(str);
	int nTestNum;
	nTestNum = _ttoi(str);
	cout << nTestNum << endl;
	return nTestNum;
}
//void CGermDlg::simulate(vector<Cell> cells, vector<Germ> germsA, vector<Germ> germsB, vector<Germ> germsC)
void CGermDlg::simulate(void)
{
	UpdateData(TRUE);
	int num;
	num = getNumFromDlg(m_strNumCell);
	if (num != 0) {
		cells.resize(num);
	}
	num = getNumFromDlg(m_strNumGermA);
	if (num != 0) {
		germsA.resize(num);
	}
	num = getNumFromDlg(m_strNumGermB);
	if (num != 0) {
		germsB.resize(num);
	}
	num = getNumFromDlg(m_strNumGermC);
	if (num != 0) {
		germsC.resize(num);
	}
	num = getNumFromDlg(m_strTimeGermA);
	if (num != 0) {
		germATime = num;
	}
	num = getNumFromDlg(m_strTimeGermB);
	if (num != 0) {
		germBTime = num;
	}
	num = getNumFromDlg(m_strTimeGermC);
	if (num != 0) {
		germCTime = num;
	}
	

	/*cells.resize(n);
	germsA.resize(ng1);
	germsB.resize(ng2);
	germsC.resize(ng3);
	germATime = d1;
	germBTime = d2;
	germCTime = d3;*/

	// start to simulate
	nNormalCell = cells.size();
	cout << "Cell number: " << nNormalCell << endl;
	t_start = std::chrono::high_resolution_clock::now();
	while (true) {
		Sleep(REPEAT_TIME_MILLISEC);

		// Show GUI
		//displayGUI();
		//OnPaint();
		Invalidate(FALSE);

		// Check end condition
		if (isEndCondition()) {
			return;
		}

		// processing check and move
		checkInfection();

		// move
		moveAll();
	}
}


void CGermDlg::OnBnClickedOk2()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	AfxMessageBox(_T("Hello"));
	// start to simulate
	
	//simulate(cells, germsA, germsB, germsC);
	//std::thread myThread(foo, 10);
	/*int* input = new int;
	*input = 9001;*/
	void* pCells = &cells;
	void* pGermA = &germsA;
	void* pGermB = &germsB;
	void* pGermC = &germsC;
	CGermDlg* pGermDlg = this;
	AfxBeginThread(threadProc, pGermDlg);
	//std::thread myThread(simulate, cells, germsA, germsB, germsC); // -lpthread

}
