#pragma once

//#include "GermDlg.h"
#include "Germ.h"

// simulStart dialog

class simulStart : public CDialogEx
{
	DECLARE_DYNAMIC(simulStart)

public:
	simulStart(CWnd* pParent = NULL);   // standard constructor
	virtual ~simulStart();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_SIMUL_START };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	
	CGermApp *pMainDg;
	afx_msg void OnBnClickedOk();
};

