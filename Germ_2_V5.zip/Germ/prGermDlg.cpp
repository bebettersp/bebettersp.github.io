// prGermDlg.cpp : implementation file
//

#include "pch.h"
#include "stdafx.h"
#include "Germ.h"
#include "prGermDlg.h"
#include "afxdialogex.h"
#include <iostream>


// prGermDlg dialog

IMPLEMENT_DYNAMIC(prGermDlg, CDialogEx)

prGermDlg::prGermDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_PRO_GERM, pParent)
{

}

prGermDlg::~prGermDlg()
{
}

void prGermDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_GERMA_NUM, m_strGermANum);
	DDX_Control(pDX, IDC_EDIT_GERMB_NUM, m_strGermBNum);
	DDX_Control(pDX, IDC_EDIT_GERMC_NUM, m_strGermCNum);
	DDX_Control(pDX, IDC_EDIT_GERMA_TIME, m_strGermATime);
	DDX_Control(pDX, IDC_EDIT_GERMB_TIME, m_strGermBTime);
	DDX_Control(pDX, IDC_EDIT_GERMC_TIME, m_strGermCTime);
}


BEGIN_MESSAGE_MAP(prGermDlg, CDialogEx)
	ON_BN_CLICKED(IDOK, &prGermDlg::OnBnClickedOk)
END_MESSAGE_MAP()


// prGermDlg message handlers


int prGermDlg::getNumFromDlg(CEdit &_str)
{
	CString str;
	_str.GetWindowTextW(str);
	if (str == "")
		AfxMessageBox(str);
	//std::cout << str << std::endl;
	int nTestNum;
	nTestNum = _ttoi(str);
	std::cout << nTestNum << std::endl;
	return nTestNum;
}

void prGermDlg::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	CDialogEx::OnOK();
	
	// Set Germ Number from Germ GUI
	CString str;
	m_strGermANum.GetWindowTextW(str);
	if (str == "")
		m_germANum = DEFAULT_GERMA_NUM;
	else
		m_germANum = _ttoi(str);
	
	// Set Germ Time from Germ GUI
	str = "";
	m_strGermATime.GetWindowTextW(str);
	if (str == "")
		m_germATime= DEFAULT_GERMA_TIME;
	else
		m_germATime = _ttoi(str);

	//std::cout << m_germANum << " " << m_germATime << std::endl;

	// Set Germ Number from Germ GUI
	str = "";
	m_strGermBNum.GetWindowTextW(str);
	if (str == "")
		m_germBNum = DEFAULT_GERMB_NUM;
	else
		m_germBNum = _ttoi(str);

	// Set Germ Time from Germ GUI
	str = "";
	m_strGermBTime.GetWindowTextW(str);
	if (str == "")
		m_germBTime = DEFAULT_GERMB_TIME;
	else
		m_germBTime = _ttoi(str);

	//std::cout << m_germBNum << " " << m_germBTime << std::endl;

	// Set Germ Number from Germ GUI
	str = "";
	m_strGermCNum.GetWindowTextW(str);
	if (str == "")
		m_germCNum = DEFAULT_GERMC_NUM;
	else
		m_germCNum = _ttoi(str);

	// Set Germ Time from Germ GUI
	str = "";
	m_strGermCTime.GetWindowTextW(str);
	if (str == "")
		m_germCTime = DEFAULT_GERMC_TIME;
	else
		m_germCTime = _ttoi(str);

	//std::cout << m_germCNum << " " << m_germCTime << std::endl;

}
