﻿
// GermDlg.h: 헤더 파일
//
#include <iostream>
#include <vector>
#include <map>
#include <chrono>
#include <string>
#include "windows.h"
#include <thread>
#include "simulStart.h"
using namespace std;
#pragma once
#define MAPSIZE 15
#define REPEAT_TIME_MILLISEC 300
//#pragma comment(linker, "/entry:WinMainCRTStartup /subsystem:console")

enum Direction {
	NORTH = 0,
	EAST,
	SOUTH,
	WEST
};

class Cell;
class Germ;

// CGermDlg 대화 상자
class CGermDlg : public CDialogEx
{
// 생성입니다.
public:
	CGermDlg(CWnd* pParent = nullptr);	// 표준 생성자입니다.
	HACCEL m_hAccel;
// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_GERM_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 지원입니다.
	BOOL PreTranslateMessage(MSG* pMsg);

// 구현입니다.
protected:
	HICON m_hIcon;
	CImage m_imgNormalCell;
	CImage m_imgInFectCell;
	CImage m_imgInFectCellByA;
	CImage m_imgInFectCellByB;
	CImage m_imgInFectCellByC;
	CImage m_imgGermA;
	CImage m_imgGermB;
	CImage m_imgGermC;
	// 생성된 메시지 맵 함수
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CEdit m_strNumCell;
	CEdit m_strNumGermA;
	CEdit m_strNumGermB;
	CEdit m_strNumGermC;
	CEdit m_strTimeGermA;
	CEdit m_strTimeGermB;
	CEdit m_strTimeGermC;
	bool ctrlXPressed;
	map <int, vector<int>> dire;// = { {NORTH, {-1,0}}, {EAST, {0,1}}, {SOUTH, {1,0}}, {WEST, {0,-1}} };
	bool isEndProcess = false;
	double elapsed_time_ms;
	int nNormalCell;
	int nInFectCell;
	int nSimulationTime;
	string endReason{ "" };
	std::chrono::steady_clock::time_point t_start;// = std::chrono::high_resolution_clock::now();
	
	vector<Cell> cells;
	vector<Germ> germsA;
	vector<Germ> germsB;
	vector<Germ> germsC;
	int germATime;
	int germBTime;
	int germCTime;
	
	void simulate();
	bool isEndCondition();
	void printResult();
	void checkInfection();
	void moveAll();
	afx_msg void OnParamCell();
	afx_msg void OnParamGerm();
	afx_msg void OnParamSimulTime();
	afx_msg void OnSimulateStart();
	afx_msg void OnBnClickedStart();
	afx_msg void OnAcceleratorCtrlX();
};

class COMMON
{
public:
	int r, c;
	COMMON() : r(rand() % MAPSIZE), c(rand() % MAPSIZE) {
		while (true) {
			//cout << r << " " << c;
			int temp = (r - (MAPSIZE >> 1)) * (r - (MAPSIZE >> 1)) + (c - (MAPSIZE >> 1)) * (c - (MAPSIZE >> 1));
			//cout << temp << endl;
			if ( temp <= (MAPSIZE >> 1) * (MAPSIZE >> 1) ) {
				break;
			}
			r = rand() % MAPSIZE;
			c = rand() % MAPSIZE;
		}
	};
	~COMMON() {};
	map <int, vector<int>> dire = { {NORTH, {-1,0}}, {EAST, {0,1}}, {SOUTH, {1,0}}, {WEST, {0,-1}} };
	void move()
	{
		int direct = rand() % 4;

		r += dire[direct][0];
		c += dire[direct][1];

		//if (r < 0 || c < 0 || r >= MAPSIZE || c >= MAPSIZE) {
		int temp = (r - (MAPSIZE >> 1)) * (r - (MAPSIZE >> 1)) + (c - (MAPSIZE >> 1)) * (c - (MAPSIZE >> 1));
		if (temp > (MAPSIZE >> 1) * (MAPSIZE >> 1)) {
			// limit condition?? just pass at this time.
			r -= dire[direct][0];
			c -= dire[direct][1];
		}
	}
};

class Germ : public COMMON
{
private:
public:
	int time;
	Germ() : time(10) {};
	~Germ() {};
};

class Cell : public COMMON
{
private:
public:
	bool infected;
	bool byA, byB, byC;
	Cell() : infected{ false }, byA{ false }, byB{ false }, byC{ false } {};
	~Cell() {};

	int isInfectedBy(vector<Germ>& _germs) {
		int cr = r;
		int cc = c;
		for (int j = 0; j < _germs.size(); j++) {
			if (cr == _germs[j].r && cc == _germs[j].c) {
				infected = true;
				return j;
			}
		}
		return -1;
	}
};