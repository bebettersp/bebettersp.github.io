#pragma once
#include "afxwin.h"


// cellDlg dialog

class cellDlg : public CDialogEx
{
	DECLARE_DYNAMIC(cellDlg)

public:
	cellDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~cellDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_PRO_CELL };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CEdit m_numberCell;
	int m_intCell;
	afx_msg void OnBnClickedOk();
};
