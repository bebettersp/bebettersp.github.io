// prSimulTime.cpp : implementation file
//

#include "pch.h"
#include "stdafx.h"
#include "Germ.h"
#include "prSimulTime.h"
#include "afxdialogex.h"
#include <iostream>
using namespace std;

// prSimulTime dialog

IMPLEMENT_DYNAMIC(prSimulTime, CDialogEx)

prSimulTime::prSimulTime(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_PRO_SIMUL_TIME, pParent)
{

}

prSimulTime::~prSimulTime()
{
}

void prSimulTime::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_SIMUL_TIME, m_strSimulTime);
}


BEGIN_MESSAGE_MAP(prSimulTime, CDialogEx)
	ON_BN_CLICKED(IDOK, &prSimulTime::OnBnClickedOk)
END_MESSAGE_MAP()


// prSimulTime message handlers


void prSimulTime::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	CDialogEx::OnOK();

	CString str;
	m_strSimulTime.GetWindowTextW(str);
	if (str == "")
		m_nSimulTime = DEFAULT_SIMUL_TIME;
	else
		m_nSimulTime = _ttoi(str);

	cout << m_nSimulTime << endl;
	
}
