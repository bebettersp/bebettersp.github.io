#pragma once
#include "afxwin.h"

#define DEFAULT_GERMA_NUM 4
#define DEFAULT_GERMA_TIME 10
#define DEFAULT_GERMB_NUM 5
#define DEFAULT_GERMB_TIME 15
#define DEFAULT_GERMC_NUM 6
#define DEFAULT_GERMC_TIME 18

// prGermDlg dialog

class prGermDlg : public CDialogEx
{
	DECLARE_DYNAMIC(prGermDlg)

public:
	prGermDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~prGermDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_PRO_GERM };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	int getNumFromDlg(CEdit &_str);
	CEdit m_strGermANum;
	CEdit m_strGermBNum;
	CEdit m_strGermCNum;
	CEdit m_strGermATime;
	CEdit m_strGermBTime;
	CEdit m_strGermCTime;
	int m_germANum;
	int m_germATime;
	int m_germBNum;
	int m_germBTime;
	int m_germCNum;
	int m_germCTime;
};
