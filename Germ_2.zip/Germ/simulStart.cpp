// simulStart.cpp : implementation file
//
#include "pch.h"
#include "stdafx.h"
#include "Germ.h"
#include "GermDlg.h"
#include "simulStart.h"
#include "afxdialogex.h"
#include <iostream>
using namespace std;

// simulStart dialog

IMPLEMENT_DYNAMIC(simulStart, CDialogEx)

simulStart::simulStart(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_SIMUL_START, pParent)
{
	pMainDg = (CGermApp*)::AfxGetMainWnd();
}

simulStart::~simulStart()
{
}

void simulStart::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(simulStart, CDialogEx)
	//ON_BN_CLICKED(IDOK, &pParent->OnBnClickedOk)
	ON_BN_CLICKED(IDOK, &simulStart::OnBnClickedOk)
END_MESSAGE_MAP()


// simulStart message handlers


void simulStart::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	CDialogEx::OnOK();
	std::cout << "sdfkljsdlkfjsdkljf\n";
	CGermDlg *pgermdlg = (CGermDlg *)pMainDg;
	pgermdlg->OnBnClickedStart();

}
