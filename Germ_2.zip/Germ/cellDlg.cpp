// cellDlg.cpp : implementation file
//

#include "pch.h"
#include "stdafx.h"
#include "Germ.h"
#include "cellDlg.h"
#include "afxdialogex.h"
#include <iostream>

// cellDlg dialog

IMPLEMENT_DYNAMIC(cellDlg, CDialogEx)

cellDlg::cellDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_PRO_CELL, pParent)
{

}

cellDlg::~cellDlg()
{
}

void cellDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_CELL_NUM, m_numberCell);
}


BEGIN_MESSAGE_MAP(cellDlg, CDialogEx)
	ON_BN_CLICKED(IDOK, &cellDlg::OnBnClickedOk)
END_MESSAGE_MAP()


// cellDlg message handlers


void cellDlg::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	CDialogEx::OnOK();
	CString str;
	m_numberCell.GetWindowTextW(str);
	if (str == "")
		m_intCell = 10;
	else
		m_intCell = _ttoi(str);
	std::cout << m_intCell << std::endl;
}
